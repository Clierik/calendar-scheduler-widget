export class EventOfView {
    date: any;
    dateString: string;
    dayType: string;
}